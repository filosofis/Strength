package com.lundqvist.oscar.strength.ui;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.lundqvist.oscar.strength.R;
import com.lundqvist.oscar.strength.model.Program;

import timber.log.Timber;

/**
 * Created by Oscar on 2018-01-27.
 */

public class Tab3programs extends Fragment {
    private DatabaseReference rootRef;
    private DatabaseReference programsRef;
    private ValueEventListener mPostListener;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;

    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.tab3programs, container, false);

        recyclerView = (RecyclerView) rootView.findViewById(R.id.recycler_view);


        rootRef = FirebaseDatabase.getInstance().getReference();
        programsRef = rootRef.child("programs");

        System.out.println("Create View");
        return rootView;
    }
    @Override
    public void onStart() {
        super.onStart();
        // TODO: 2018-08-05 Change the names  
        ValueEventListener postListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                System.out.println("On Data Change");
                Program program;
                for(DataSnapshot ds : dataSnapshot.getChildren()){
                    program = dataSnapshot.getValue(Program.class);
                    System.out.println(program.toString());
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Getting Post failed, log a message
                Timber.w(databaseError.toException(), "loadPost:onCancelled");
                // [START_EXCLUDE]
                System.out.println("Failed to load post");
                // [END_EXCLUDE]
            }
        };
        rootRef.addValueEventListener(postListener);
        mPostListener = postListener;

    }
    @Override
    public void onStop() {
        super.onStop();

        // Remove post value event listener
        if (mPostListener != null) {
            rootRef.removeEventListener(mPostListener);
        }
    }
}
